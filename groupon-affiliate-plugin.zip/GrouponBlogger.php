<?php
/*
Plugin Name: Groupon for Wordpress
Plugin URI: 
Description: 
Version: 0.0.1
Author: 15Letters
Author URI: http://www.15letters.com
*/

class GrouponBlogger {
	function GrouponBlogger() {
		define('GROUPON_VERSION', '0.0.2');
		define('GROUPON_ABSPATH', WP_PLUGIN_DIR.'/'.plugin_basename( dirname(__FILE__) ).'/' );
		define('GROUPON_URLPATH', WP_PLUGIN_URL.'/'.plugin_basename( dirname(__FILE__) ).'/' );
		
		include_once (dirname (__FILE__)."/admin/GrouponBloggerAdmin.php");
		include_once (dirname (__FILE__)."/tinymce/tinymce.php");
		
	}
}
	

add_action( 'plugins_loaded', create_function( '', 'global $grouponBlogger; $grouponBlogger = new GrouponBlogger();' ) );
// init process for button control 
//add_action('init', 'groupon_addbuttons'); 







?>