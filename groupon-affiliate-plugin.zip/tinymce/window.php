<?php
require_once( dirname( dirname(__FILE__) ) .'/GrouponBlogger-config.php');

$apikey			= get_option('grouponblogger_apikey');
$enablecj	 	= get_option('grouponblogger_usecj');
$cjid 			= get_option('grouponblogger_cjid');
$aid 			= '10837780';
$sid 			= get_option('grouponblogger_sid');
$division 		= get_option('grouponblogger_division');

if (isset($_GET['division'])) {
	$division = $_GET['division'];
}



// Get JSON for deals..
$JSONURL = 'http://api.groupon.com/v2/deals.json?client_id='.$apikey;
if ($division != 'null') $JSONURL .= '&division_id='.$division;
$grouponDealJSON = @file_get_contents($JSONURL);


if ($grouponDealJSON === false) {
	$APIerror = 'Error accessing Groupon API: you may have provided an incorrect API key - <a href="http://www.groupon.com/pages/api" target="_blank">visit the Groupon API homepage to confirm your API key</a>';
} else {
	$grouponData = json_decode($grouponDealJSON);
	// Get JSON for divisions..
	$grouponDivisionsJSON = @file_get_contents("http://api.groupon.com/v2/divisions.json?client_id=".$apikey);
	if ($grouponDivisionsJSON === false) {
		$APIerror = 'Error accessing Groupon API: you may have provided an incorrect API key - <a href="http://www.groupon.com/pages/api" target="_blank">visit the Groupon API homepage to confirm your API key</a>';
	}
	$grouponDivisions = json_decode($grouponDivisionsJSON);
}

global $wpdb;

// check for rights
if ( !is_user_logged_in() || !current_user_can('edit_posts') ) 
	wp_die(__("You are not allowed to be here"));
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>Groupon for Wordpress</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<script language="javascript" type="text/javascript" src="<?php echo get_option('siteurl') ?>/wp-includes/js/tinymce/tiny_mce_popup.js"></script>
	<script language="javascript" type="text/javascript" src="<?php echo get_option('siteurl') ?>/wp-includes/js/tinymce/utils/mctabs.js"></script>
	<script language="javascript" type="text/javascript" src="<?php echo get_option('siteurl') ?>/wp-includes/js/tinymce/utils/form_utils.js"></script>
	<script language="javascript" type="text/javascript">
	var jsonGrouponData = <?=$grouponDealJSON ?>;
	var enableCJ = new Boolean(<?=$enablecj?>);
	
	function init() {	
		tinyMCEPopup.resizeToInnerSize();
	}
	
	function insertGroupon() {	
		var content = "";
		var basicPanel = document.getElementById('basic_panel');
		var settingsForm = document.getElementById('grouponBloggerForm');
		
		// if (basicPanel.className.indexOf('current') != -1) {
			var grouponIDGroup = settingsForm.grouponID;
			var grouponID;
			for( i = 0; i < grouponIDGroup.length; i++ ) {
				if( grouponIDGroup[i].checked == true ) {
					grouponID = grouponIDGroup[i].value;
					break;
				}
			}
			
			var imageSizeID;
			var imageSizeGroup = settingsForm.imageSize;
			for( i = 0; i < imageSizeGroup.length; i++ ) {
				if( imageSizeGroup[i].checked == true ) {
					imageSizeID = imageSizeGroup[i].value;
					break;
				}
			}
			
			var imagePrefix = imageSizeID == 0 ? "small" : imageSizeID == 1 ? "medium" : "large";
			
			
			if(grouponID){
				var currentDeal = jsonGrouponData.deals[grouponID];
				var sid = document.getElementById('sid').value;
				if ((sid != null) && (sid != '')) {
					var sidParam = 'sid='+sid+'&';
				} else {
					var sidParam = '';
				}
				<?php
					if ((isset($sid)) && ($sid != '')) {
						$sidparam = 'sid='.$sid.'&';
					} else {
						$sidparam = '';
					}
				?>
				currentDeal.title = currentDeal.title.replace(/\n/g).replace(/\r/g);
				var currentImg = currentDeal[imagePrefix+"ImageUrl"].replace(/\n/g).replace(/\r/g);
				if(enableCJ == true){
					content = "<div class='grouponBlogBlock'><a class='grouponBlogLink' href='http://www.anrdoezrs.net/click-<?php echo $cjid ?>-10837780?"+sidParam+"url="+currentDeal.dealUrl+"'><img class='grouponBlogImage' src='"+currentImg+"'><h2 class='grouponBlogTitle'>"+currentDeal.title+"</h2></a></div>";
				} else {
					content = "<div class='grouponBlogBlock'><a class='grouponBlogLink' href='"+currentDeal.dealUrl+"'><img class='grouponBlogImage' src='"+currentImg+"'><span class='grouponBlogTitle'>"+currentDeal.title+"</span></a></div>";
				}
				content += "\n\n";
			}
		// }
	
		
		if(window.tinyMCE) {
			window.tinyMCE.execInstanceCommand('content', 'mceInsertContent', false, content);
			//Peforms a clean up of the current editor HTML. 
			//tinyMCEPopup.editor.execCommand('mceCleanup');
			//Repaints the editor. Sometimes the browser has graphic glitches. 
			tinyMCEPopup.editor.execCommand('mceRepaint');
			tinyMCEPopup.close();
		}
		
		return;
	}
	function refreshDivision(ele) {
		var selectedDivision = document.getElementById('grouponblogger_division').value;
		var panel_wrapper = document.getElementById('panel_wrapper');
		panel_wrapper.innerHTML = '<div style="text-align: center; width: 100%">Loading deals for ' + selectedDivision + ' - please wait...<br><br><img src="loader.gif"></div>';
		(location.href.indexOf('?') == -1) ? sepChar = '?' : sepChar = '&';
		setTimeout(
			function() {
				location.href = location.href + sepChar + 'division=' + selectedDivision;
			},
			300
		);
	}
	</script>
	<base target="_self" />
	<style>
		.panel_wrapper { min-height: 100px; padding-bottom: 30px; overflow: auto; }
		label { width: 40px; float: left; }
		#sid { float: left; margin-right: 10px; }
		.labelDesc { float: left; width: 300px; }
	</style>
	</head>
	<body id="link" onload="init();" style="display: none">
		<form id="grouponBloggerForm" action="#">
			<div class="tabs">
				<ul>
					<li id="basic_tab" class="current"><span><a href="javascript:mcTabs.displayTab('basic_tab','basic_panel');" onmousedown="return false;"><?php _e("Groupons"); ?></a></span></li>
					<li id="customize_tab"><span><a href="javascript:mcTabs.displayTab('customize_tab','custom_panel');" onmousedown="return false;"><?php _e("Customize"); ?></a></span></li>
				</ul>
			</div>
			
			<div class="panel_wrapper" id="panel_wrapper">
				<div id="basic_panel" class="panel current" style="height:75px;">
					<?php if (!isset($APIerror)) { ?>
					<select id="grouponblogger_division" name="grouponblogger_division" onChange="refreshDivision(this);">
						<?php
							echo "<option value='null'>{Auto-Lookup}</option> ";

							foreach($grouponDivisions->divisions as $thisdivision){
								$name = $thisdivision->name;
								$id	= $thisdivision->id;
								echo "<option value='$id' ". ($id == $division ? "selected" : "") . ">$name</option>";
							}
						?>
					</select>
					<br />
					<?php } ?>
					<?php
						$index = 0;
						if (!isset($APIerror)) {
							foreach($grouponData->deals as $deal){
								echo "<input type=\"radio\" name=\"grouponID\" value=\"".$index."\"" . (($index == 0) ? 'checked' : '') .">".$deal->title."<br>";
								$index++;
							}
						} else {
							echo $APIerror;
							echo '<br><br>To configure the Groupon for Wordpress plugin, click "Settings", then "Groupon for Wordpress" in your admin console.';
						}
					?>
				</div>
				
				<div id="custom_panel" class="panel" style="height:75px;">
					<input type="radio" name="imageSize" value="0">Small (50x30)<br/>
					<input type="radio" name="imageSize" value="1">Medium (100x61)<br/>
					<input type="radio" name="imageSize" value="2" checked>Large (440x267)<br/>
					<br/>
					<label for="sid">SID:</label> <input type="text" id="sid" name="sid" value="<?php echo $sid ?>"> <div class="labelDesc">The SID is an optional field for Commission Junction tracking.  You can <a target="_blank" href="http://help.cj.com/en/lo*@%29%29p/SmartRewards_FAQ.htm">read more about it here</a>.</div>
				</div>
				
				
			</div>

			<div class="mceActionPanel">
				<div style="float: left">
					<input type="button" id="cancel" name="cancel" value="<?php _e("Cancel"); ?>" onclick="tinyMCEPopup.close();" />
				</div>

				<div style="float: right">
					<input type="submit" id="insert" name="insert" value="<?php _e("Insert"); ?>" onclick="insertGroupon();" />
				</div>
			</div>
		</form>
	</body>
</html>