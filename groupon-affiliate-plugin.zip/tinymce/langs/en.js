tinyMCE.addI18n({en:{
GrouponBlogger:{	
desc : 'Insert Groupon Deal'
}}});
