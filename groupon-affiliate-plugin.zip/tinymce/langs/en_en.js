tinyMCE.addI18n({en_US:{
GrouponBlogger:{	
desc : 'Insert Groupon Deal'
}}});