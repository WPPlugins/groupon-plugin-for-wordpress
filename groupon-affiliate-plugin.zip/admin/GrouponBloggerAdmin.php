<?php

class GrouponBloggerAdmin {	
	function GrouponBloggerAdmin(){
		function groupon_blogger_options_page() {
			include('groupon_admin_options.php');
		}

		function groupon_blogger_admin_actions() {
			add_options_page('Groupon for Wordpress Settings', 'Groupon for Wordpress', 'manage_options', 'grouponBlogger', 'groupon_blogger_options_page');
		}
		
		add_action('admin_menu', 'groupon_blogger_admin_actions');
	}
}

$grouponBloggerAdmin = new GrouponBloggerAdmin();
?>