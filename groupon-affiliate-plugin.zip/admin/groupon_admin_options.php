	<?php
		if($_POST['grouponblogger_hidden'] == 'Y') {
		
			$grouponblogger_apikey = $_POST['grouponblogger_apikey'];
			update_option('grouponblogger_apikey', $grouponblogger_apikey);
		
			$grouponblogger_usecj = $_POST['grouponblogger_usecj'];
			update_option('grouponblogger_usecj', $grouponblogger_usecj == "yes");

			$grouponblogger_cjid = $_POST['grouponblogger_cjid'];
			update_option('grouponblogger_cjid', $grouponblogger_cjid);
			
			$grouponblogger_sid = $_POST['grouponblogger_sid'];
			update_option('grouponblogger_sid', $grouponblogger_sid);
			
			$grouponblogger_division = $_POST['grouponblogger_division'];
			//if($grouponblogger_division === "null") $grouponblogger_division = null;
			update_option('grouponblogger_division', $grouponblogger_division);
			
			
			?>
			<div class="updated"><p><strong><?php _e('Options saved.' ); ?></strong></p></div>
			<?php
		}
		
		$grouponblogger_apikey = get_option('grouponblogger_apikey');
		/*
		 *	There are 3 parameters to the CJ link that we'll need to pass in the link: Publisher ID (PID), Ad ID (AID), and an optional SubID (SID).
		 *	PID - This is the affiliate ID that they will need to manually input
		 *	AID - I have created a dedicated creative for this widget which is 10837780 so we can track the performance of the widget
		 *	SID - This is optional field that affiliates use to track placements.  Not all affiliates use SID's, so if there is no SID value present, the SID parameter does not need to be included in the link
		*/
		$grouponblogger_cjid = get_option('grouponblogger_cjid'); 
		$grouponblogger_sid = get_option('grouponblogger_sid'); 
		$grouponblogger_usecj = get_option('grouponblogger_usecj'); 
		$grouponblogger_division = get_option('grouponblogger_division');
		
		if ($grouponblogger_apikey != '') {
				$grouponDivisionsJSON = @file_get_contents("http://api.groupon.com/v2/divisions.json?client_id=".$grouponblogger_apikey);
				if ($grouponDivisionsJSON === false) {
					$APIerror = '<strong>Error accessing Groupon API:</strong> you may have provided an incorrect API key - <a href="http://www.groupon.com/pages/api" target="_blank">visit the Groupon API homepage to confirm your API key</a>';
				}
			$grouponDivisions = json_decode($grouponDivisionsJSON);
		}
		
?>
		<style>
			label { float: left; width: 160px; }
			input[type=text] { float: left; margin-left: 10px; margin-right: 10px; width: 320px; }
		</style>
		<div class="wrap">
			<?php    echo "<h2>" . __( 'Groupon for Wordpress Settings') . "</h2>"; ?>

			<form name="grouponblogger_form" method="post" action="<?php echo str_replace( '%7E', '~', $_SERVER['REQUEST_URI']); ?>">
				<input type="hidden" name="grouponblogger_hidden" value="Y">
				<?php    echo "<h4>" . __( 'Groupon API Info') . "</h4>"; ?>
				<p><label for="grouponblogger_apikey"><?php _e("API Key: " ); ?></label><input type="text" name="grouponblogger_apikey" value="<?php echo $grouponblogger_apikey; ?>" size="25"> 
				<?php
					if (!isset($grouponblogger_apikey) || ($grouponblogger_apikey == '') || (isset($APIerror))) {
						$hidden = 'style="visibility: hidden; display: none;"';
						echo '<input type="submit" name="Submit" value="Check Key" />';
					}
					
				?>
				- <b>Note:</b> an <a href="http://www.groupon.com/pages/api" target="_blank">API key</a> is required to post Groupon deals.
					<?php if (isset($APIerror)) echo "<br><br>" . $APIerror ?>
				</p>
				<?php
				?>
					<div <?php echo $hidden ?>>
						<?php    echo "<h4>" . __( 'Commission Junction') . "</h4>"; ?>
						Please enter your Commission Junction affiliate information below to start earning money for your referrals.  If you're not already a Groupon affiliate, you can <a href='http://www.groupon.com/pages/affiliates' target='_blank'>sign up here.</a>
						<p><?php _e("Enable Commision Junction: " ); ?><input type="checkbox" name="grouponblogger_usecj" value="yes" <?php echo $grouponblogger_usecj ? 'checked' : ''; ?>></p>
						<p><label for="grouponblogger_cjid"><?php _e("CJ PID (Publisher ID): " ); ?></label><input type="text" name="grouponblogger_cjid" value="<?php echo $grouponblogger_cjid; ?>" size="25"></p><br/>
						<p><label for="grouponblogger_sid"><?php _e("SID (optional): " ); ?></label><input type="text" name="grouponblogger_sid" value="<?php echo $grouponblogger_sid; ?>" size="25"> - The SID is an optional field for Commission Junction tracking.  You can <a target="_blank" href="http://help.cj.com/en/lo*@%29%29p/SmartRewards_FAQ.htm">read more about it here</a>.</p>
						<hr />
						<?php    echo "<h4>" . __( 'Groupon Settings') . "</h4>"; ?>
						<label for="grouponblogger_division">Default Location:</label> <select name="grouponblogger_division">
							<?php
								echo "<option value='null'>{Auto-Lookup}</option>";
								
							
								foreach($grouponDivisions->divisions as $division){
									$name = $division->name;
									$id	= $division->id;
									echo "<option value='$id' ". ($id == $grouponblogger_division ? "selected" : "") . ">$name</option>";
								}
							?>
						</select>
					</div>
				<p class="submit">
					<input type="submit" name="Submit" value="<?php _e('Update Options') ?>" />
				</p>
			</form>
		</div>